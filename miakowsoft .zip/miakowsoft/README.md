# miakowsoft v1.1.0

Cross-platform public-source OSINT research tool. Runs on Linux, Windows, macOS and Android Termux with Python 3.10+.

Public information can be incomplete or misleading. A username match does not establish identity. IP geolocation describes network infrastructure, not a person's address.

## Quick start

```bash
python main.py
```

No mandatory third-party packages. The engine uses the Python standard library only.

Optional (for enhanced MX lookups):

```bash
python -m pip install dnspython
```

### Termux

```bash
pkg install python
python main.py
```

## Non-interactive use

```bash
python main.py --list-sources
python main.py --target example.org --type domain --export json
python main.py --target 8.8.8.8 --type ip --export md
python main.py --target analyst --type username --export csv
python main.py --target "exact phrase" --type search --export txt
python main.py --version
```

Supported target types: `auto`, `domain`, `ip`, `email`, `phone`, `username`, `search`.

Reports are written under `data/reports/` by default.

## Sources (keyless baseline)

20 registered public collectors including:

DNS (Cloudflare + Google DoH), RDAP domain/IP, Certificate Transparency (crt.sh),
Internet Archive CDX, ipwho.is, BGPView, AlienVault OTX, abuse.ch ThreatFox,
HackerTarget hostsearch + reverse IP, urlscan.io, GitHub, GitLab, Hacker News,
email MX, Gravatar, DuckDuckGo, phone normalization.

## Multi-stage pivot

```bash
python main.py --target example.com --type domain --depth 1
```

Depth 0 = single target only. Depth 1–2 extracts domains/IPs/usernames from
observations and investigates them automatically (bounded by QT_MAX_PIVOT_TARGETS).

Every source returns an explicit status: `ok`, `empty`, `skipped`, or `error`. Records carry retrieval time, source URL (when available), evidence label and a confidence qualifier that distinguishes direct registry data from indirect observations.

## Design principles

- No fabricated results.
- No authentication bypass, credential checking or private-content access.
- TLS verification stays enabled.
- Private / loopback / reserved IPs are rejected for public enrichment.
- Bounded concurrency (default 6 workers).
- Correlation reports repeated indicators across sources without claiming identity.
- Ctrl+C cancels cleanly.
- Colors can be disabled with `--no-color` or `NO_COLOR=1`.

## Project layout

```
main.py
miakowsoft/
  __init__.py
  engine.py
  models.py
  reporting.py
  security.py
  sources.py
  ui.py
  utils.py
requirements.txt
README.md
.env.example
```

## License / use

Intended for legitimate open-source intelligence research and education. Respect the terms of service of every upstream provider and applicable law.
